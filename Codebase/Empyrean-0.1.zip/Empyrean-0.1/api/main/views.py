from main import app

# Default routes that don't belong in any of the blueprint views
