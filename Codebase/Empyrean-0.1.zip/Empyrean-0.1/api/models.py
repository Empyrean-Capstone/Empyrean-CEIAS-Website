from main import app
from flask_sqlalchemy import SQLAlchemy

#db = SQLAlchemy( app )